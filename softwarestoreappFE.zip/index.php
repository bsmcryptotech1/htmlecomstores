<?php
$file = "admin/data/home.txt";
$fileproduct = "admin/data/product.txt";
$fileseo = "admin/data/seohome.txt";
$filesm = "admin/data/smhome.txt";

if (file_exists($file)) $data = json_decode(file_get_contents($file));
if (file_exists($fileproduct)) $dataproduct = json_decode(file_get_contents($fileproduct));
if (file_exists($fileseo)) $dataseo = json_decode(file_get_contents($fileseo));
if (file_exists($filesm)) $datasm = json_decode(file_get_contents($filesm));

	include('includes/header.php');
	
	switch($settings->currency) {
		case 'USD': $sym = '$'; break;
		case 'GBP': $sym = '£'; break;
		case 'EUR': $sym = '€'; break;
	}

$allDataSM = array(
    0 => array('title' => 'Twitter Followers', 'name' => 'tw_fo_tx', 'price' => 'tw_fo_pr', 'image' => 'twitter.png'),
    1 => array('title' => 'Instagram Followers', 'name' => 'in_fo_tx', 'price' => 'in_fo_pr', 'image' => 'instagram.png'),
    2 => array('title' => 'Facebook Like', 'name' => 'fb_lk_tx', 'price' => 'fb_lk_pr', 'image' => 'facebook.png'),
    3 => array('title' => 'Youtube Views', 'name' => 'yo_vw_tx', 'price' => 'yo_vw_pr', 'image' => 'youtube.png'),
    4 => array('title' => 'Twitter Retweet', 'name' => 'tw_rt_tx', 'price' => 'tw_rt_pr', 'image' => 'twitter.png'),
    5 => array('title' => 'Instagram Likes', 'name' => 'in_lk_tx', 'price' => 'in_lk_pr', 'image' => 'instagram.png'),
    6 => array('title' => 'Facebook Shares', 'name' => 'fb_sh_tx', 'price' => 'fb_sh_pr', 'image' => 'facebook.png'),
    7 => array('title' => 'Youtube Subscribes', 'name' => 'yo_su_tx', 'price' => 'yo_su_pr', 'image' => 'youtube.png')
);

$allDataSEO = array(
    0 => array('title' => 'BACKLINK PACKAGES', 'name' => 'tw_fo_tx', 'price' => 'tw_fo_pr', 'image' => 'backlinks.png'),
    1 => array('title' => 'PRESS RELEASES', 'name' => 'in_fo_tx', 'price' => 'in_fo_pr', 'image' => 'pressreleases.png'),
    2 => array('title' => 'CONTENT WRITING', 'name' => 'fb_lk_tx', 'price' => 'fb_lk_pr', 'image' => 'articlewriting.png'),
    3 => array('title' => 'ARTICLE SUBMISSIONS', 'name' => 'yo_vw_tx', 'price' => 'yo_vw_pr', 'image' => 'articlesubmission.png'),
    4 => array('title' => 'SOCIAL BOOKMARKING', 'name' => 'tw_rt_tx', 'price' => 'tw_rt_pr', 'image' => 'socialbookmarking.png'),
    5 => array('title' => 'VIDEO MARKETING', 'name' => 'in_lk_tx', 'price' => 'in_lk_pr', 'image' => 'videomarketing.png'),
    6 => array('title' => 'LINK INDEXING', 'name' => 'fb_sh_tx', 'price' => 'fb_sh_pr', 'image' => 'linkindexing.png'),
    7 => array('title' => 'SOCIAL ACCOUNTS', 'name' => 'yo_su_tx', 'price' => 'yo_su_pr', 'image' => 'socialaccounts.png')
);
?>
<!-- Site Description -->
<div class="presentation container">
	<h2><?php echo $data->main_headline != '' ? stripslashes($data->main_headline) : 'We are <span class="violet">SocialPiggy</span>, a viral marketing company.'; ?></h2>
	<p><?php echo $data->main_headline != '' ? stripslashes($data->sub_headline) : 'We create viral buzz around the internet...'; ?></p>
</div>
<?php 
$data->hero_enable = 0;
if (isset($data->hero_enable) && $data->hero_enable == 1){  ?>
<div class="what-we-do container hero">
<div class="row">
<div class="span6 <?php echo $data->hero_video_position == "left"? "" : "right";  ?>">
<?php echo stripslashes($data->hero_video);  ?>
</div>

<div class="span6">
	<h2><?php echo $data->hero_title != '' ? stripslashes($data->hero_title) : 'We are <span class="violet">SocialPiggy</span>, a viral marketing company.'; ?></h2>
	<p><?php echo $data->hero_desc != '' ? stripslashes($data->hero_desc) : 'We create viral buzz around the internet...'; ?></p>
</div>
</div>
</div>
<?php }  ?>
<?php
	$fixed_str = '	<input type="hidden" name="cmd" value="_cart">
					<input type="hidden" name="business" value="'.$settings->paypal.'">
					<input type="hidden" name="lc" value="US">
					<input type="hidden" name="add" value="1">';
	$btn = '<input type="submit" class="btn_new" value="Buy Now" />';
?>
<!-- Products -->
<div class="what-we-do container">
	<div class="row">
        <?php

for ($i = 1; $i < 5; $i++) {

    for ($j = 1; $j <= $settings->total_products; $j++) {
        if ($dataproduct->product_name->$j == $data->product->$i)
        {
            ?>
            <div class="service span6 productbox">
                <p class="mg15"></p>
                <div class="left span2">
                    <div class="icon-awesome "> <img src="http://<?php echo $_SERVER['HTTP_HOST']; ?>/admin/data/images/<?php echo $dataproduct->product_img->$j; ?>" style="max-width:150px;"> </div>
                </div>
                <div class="left span3 spleft"><h4><?php echo stripslashes($dataproduct->product_name->$j); ?></h4><p><?php echo stripslashes($dataproduct->product_desc->$j); ?></p>
				<p></p>Price : <?php echo $sym; ?> <?php echo $dataproduct->price->$j; ?><br><p></p><p></p>
                    <form id="signup" action="<?php echo paypal_path; ?>" method="post">
                        <input type="hidden" name="cmd" value="_cart">
                        <input type="hidden" name="business" value="<?php echo $settings->paypal; ?>">
                        <input type="hidden" name="lc" value="US">
                        <input type="hidden" name="add" value="1">
                        <input type="hidden" name="item_name" value="<?php echo stripslashes($dataproduct->product_name->$j); ?>">
                        <input type="hidden" name="amount" value="<?php echo $dataproduct->price->$j; ?>">
                        <input type="hidden" name="return" value="<?php echo $dataproduct->link->$j; ?>">
                        <input type="hidden" name="currency_code" value="<?php echo $settings->currency; ?>">
                        <!-- <input type="image" src="images/bn.png" border="0" name="submit"> -->
                        <?php echo $btn; ?>
                    </form>
					</div>
                <div class="clear"></div>
            </div>

            <?
        }
    }
}
        ?>
	</div>
</div>
<!-- SEO -->
<div class="presentation container">
	<h2><?php echo $dataseo->main_headline != '' ? stripslashes($dataseo->main_headline) : 'We are <span class="violet">SocialPiggy</span>, a viral marketing company.'; ?></h2>
	<p><?php echo $dataseo->main_headline != '' ? stripslashes($dataseo->sub_headline) : 'We create viral buzz around the internet...'; ?></p>
</div>
<div class="what-we-do container">
	<div class="row">
<?php

for ($t = 1; $t < 5; $t++) {

    for ($j = 0; $j < count($allDataSEO); $j++) {
        if ($allDataSEO[$j]["name"] == $data->seoservice->$t)
        {
            ?>
		<div class="service span3">
			<div class="icon-awesome"><img src="images/<?php echo $allDataSEO[$j]["image"]; ?>"></div>
			<h4><?php echo $allDataSEO[$j]["title"]; ?></h4>
			<p></p>
			<form id="signup" action="<?php echo paypal_path; ?>" method="post">
				<input type="hidden" name="item_name" value="<?php echo $allDataSEO[$j]["title"]; ?>">
				
				<?php echo $fixed_str; ?>
				<input type="hidden" name="on0" value="Selected value ">
				<?php
					for($tmp = 1; $tmp <= count((array)$dataseo->$allDataSEO[$j]["name"]); $tmp++) {
						echo '<input type="hidden" name="option_select'.$tmp.'" value="'.filter_var($dataseo->$allDataSEO[$j]["name"]->$tmp, FILTER_SANITIZE_NUMBER_INT).'">';
						echo '<input type="hidden" name="option_amount'.$tmp.'" value="'.$dataseo->$allDataSEO[$j]["price"]->$tmp.'">';
					}
				?>
				<div class="styled-select">
					<select name="os0">
						<?php
							$tmp = 1;
							for($i = 1; $i <= count((array)$dataseo->$allDataSEO[$j]["name"]); $i++) {
								echo '<option value="'.	filter_var($dataseo->$allDataSEO[$j]["name"]->$i, FILTER_SANITIZE_NUMBER_INT).'">'.$dataseo->$allDataSEO[$j]["name"]->$i.' - '.$sym.$dataseo->$allDataSEO[$j]["price"]->$i.'</option>';
								$tmp++;
							}
						?>
					</select>
				</div>
				<input type="hidden" name="on1" value="SiteURL:"> Enter URL
				<input class="tb7" type="text" name="os1" id="TwitterRetweet" maxlength="200">
				<input type="hidden" name="currency_code" value="<?php echo $settings->currency; ?>"><br>
				<center><!-- <input type="image" src="images/bn.png" border="0" name="submit"> --> <?php echo $btn; ?></center>
			</form>
			<p></p>
		</div>
        <?
        }
    }
}
?>
	</div>
</div>
<!-- Social Media -->
<div class="presentation container">
	<h2><?php echo $datasm->main_headline != '' ? stripslashes($datasm->main_headline) : 'We are <span class="violet">SocialPiggy</span>, a viral marketing company.'; ?></h2>
	<p><?php echo $datasm->main_headline != '' ? stripslashes($datasm->sub_headline) : 'We create viral buzz around the internet...'; ?></p>
</div>
    <div class="what-we-do container">
        <div class="row">
            <?php

            for ($t = 1; $t < 5; $t++) {

                for ($j = 0; $j < count($allDataSM); $j++) {
                    if ($allDataSM[$j]["name"] == $data->smservice->$t)
                    {
                        ?>
                        <div class="service span3">
                            <div class="icon-awesome"><img src="images/<?php echo $allDataSM[$j]["image"]; ?>"></div>
                            <h4><?php echo $allDataSM[$j]["title"]; ?></h4>
                            <p></p>
                            <form id="signup" action="<?php echo paypal_path; ?>" method="post">
                                <input type="hidden" name="item_name" value="<?php echo $allDataSM[$j]["title"]; ?>">
								
                                <?php echo $fixed_str; ?>
								<input type="hidden" name="on0" value="Selected value " />
                                <?php
                                for($tmp = 1; $tmp <= count((array)$datasm->$allDataSM[$j]["name"]); $tmp++) {
                                    echo '<input type="hidden" name="option_select'.$tmp.'" value="'.filter_var($datasm->$allDataSM[$j]["name"]->$tmp, FILTER_SANITIZE_NUMBER_INT).'">';
                                    echo '<input type="hidden" name="option_amount'.$tmp.'" value="'.$datasm->$allDataSM[$j]["price"]->$tmp.'">';
                                }
                                ?>
                                <div class="styled-select">
                                    <select name="os0">
                                        <?php
                                        $tmp = 1;
                                        for($i = 1; $i <= count((array)$datasm->$allDataSM[$j]["name"]); $i++) {
                                            echo '<option value="'.	filter_var($datasm->$allDataSM[$j]["name"]->$i, FILTER_SANITIZE_NUMBER_INT).'">'.$datasm->$allDataSM[$j]["name"]->$i.' - '.$sym.$datasm->$allDataSM[$j]["price"]->$i.'</option>';
                                            $tmp++;
                                        }
                                        ?>
                                    </select>
                                </div>
                                <input type="hidden" name="on1" value="SiteURL:"> Enter URL
                                <input class="tb7" type="text" name="os1" id="TwitterRetweet" maxlength="200">
                                <input type="hidden" name="currency_code" value="<?php echo $settings->currency; ?>"><br>
                                <center><!-- <input type="image" src="images/bn.png" border="0" name="submit"> --> <?php echo $btn; ?></center>
                            </form>
                            <p></p>
                        </div>
                    <?
                    }
                }
            }
            ?>
        </div>
    </div>
<!-- Latest Work -->

<?php if ($settings->total_testi > 0) { ?>
	<!-- Testimonials -->
	<div class="testimonials container">
		<div class="testimonials-title">
			<h3>Testimonials</h3>
		</div>
		<div class="row">
			<div class="tab-content">
				<?php 
					for($i = 1; $i <= $settings->total_testi; $i++) {
						echo '
							<div class="testimonial-list">
								<img src="admin/data/images/'.$data->testi_img->$i.'" title="" alt="">
								<p>'.stripslashes($data->testi_msg->$i).'<br><span class="violet" style="color: '.$settings->dark_color.';">'.$data->testi_auth->$i.'</span></p>
							</div>
						';
					}
				?>
			</div>
		</div>
	</div>
<?php } ?>
<style>
	.what-we-do .service { border-bottom: 2px solid <?php echo $settings->dark_color; ?> }
</style>
<?php include('includes/footer.php'); ?>