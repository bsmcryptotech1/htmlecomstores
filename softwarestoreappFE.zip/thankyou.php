<?php
	$data = json_decode(file_get_contents('admin/data/contact.txt'));
	include('includes/header.php');
	if(isset($_REQUEST['name'])) {
		$to = $settings->email;
		$subject = 'New Order from Website';
		$headers = "From: " . strip_tags($_REQUEST['email']) . "\r\n";
		$headers .= "Reply-To: ". strip_tags($_REQUEST['email']) . "\r\n";
		//$headers .= "CC: susan@example.com\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		$message = "Hi, An order has been placed.";
		$message .= "<br /><br /><br />Name: ".$_REQUEST['name'];
		$message .= "<br />Email: ".$_REQUEST['email'];
		$message .= "<br />Service: ".$_REQUEST['service'];
		$message .= "<br />Order Detail: ".$_REQUEST['order_detail'];
		mail($to, $subject, $message, $headers);
		$msg = 'Your Message has been sent. Thank You.';
	}
	$btn = '<input type="submit" style="font-size: 14px; font-style: normal; height: auto; color: #fff; border-radius: 15px; border: none;" class="btn_new" value="SUBMIT" />';
?>
<style type="text/css">
@media print {
.gm-style .gmnoprint, .gmnoprint {
	display:none
}
}
 @media screen {
.gm-style .gmnoscreen, .gmnoscreen {
	display:none
}
}
</style>
<!-- Page Title -->
<div class="page-title">
        <div class="container">
    <div class="row">
            <div class="span12"> <i class="icon-envelope-alt page-title-icon"></i>
        <h2>Thank You For Your Order</h2>
      </div>
          </div>
  </div>
      </div>

<!-- Contact Us -->
<div class="contact-us container">
        <div class="row">
		<?php
			if (isset($msg) && $msg != '')
				echo '<div class="alert alert-success" style="text-align: center;">'.$msg.'</div>';
		?>
    <div class="contact-form span7" style="margin: 0px auto; float: none; width: 790px;">
        <p>Thank you for making a payment for your order. Please fill out your order details in the form below and submit it, we'll contact you back in 24-48hrs about it.</p>
		<form method="post" action="" style="margin: 0px auto; width: 500px;">
	        <label for="name" class="nameLabel">Name</label>
	        <input id="name" type="text" name="name" placeholder="Enter your name...">
	        <label for="email" class="emailLabel">Email</label>
	        <input id="email" type="text" name="email" placeholder="Enter your email...">
	        <label for="service">Service</label>
	        <input id="service" type="text" name="service" placeholder="Name of the Service you ordered...">
	        <label for="order" class="messageLabel">Order Details</label>
	        <textarea id="order_detail" name="order_detail" placeholder="Please send us the details of your order - any custom requests, web links or anything else we may need to complete your order." name="message"></textarea>
	        <!-- <button type="submit">Send</button> -->
			<center><div style="margin: 0px auto; text-align: center; width: 100px;"><?php echo $btn; ?></div></center>
		</form>
          </div>
          </div>
  </div>
<?php include('includes/footer.php'); ?>