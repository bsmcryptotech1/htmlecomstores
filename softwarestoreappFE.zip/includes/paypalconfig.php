﻿<?php 
@define('paypal_path', 'https://www.paypal.com/cgi-bin/webscr'); //
@define('paypal_id', 'paypaladdresshere@email.com'); // paypal goes here


?>