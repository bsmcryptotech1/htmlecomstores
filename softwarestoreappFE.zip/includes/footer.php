<!-- Footer -->
        <footer>
            <div class="container">
                <div class="row">
                    <div class="widget span6">
                        <h4>About Us</h4>
                        <p><?php echo stripslashes($settings->about); ?></p>
                    </div>

                    <div class="widget span6">
                        <h4>Contact Us</h4>
                        <p><i class="icon-envelope-alt"></i> Email: <a href="mailto:<?php echo $settings->email; ?>" style="color: <?php echo $settings->light_color; ;?>"><?php echo $settings->email; ?></a></p>
						<p></p>
						<p>
						<?php if ($settings->fblink != '' || $settings->twlink != '' || $settings->gplink != '') { ?>
							Connect with us on :
							<?php if ($settings->fblink != '') { ?>
								<a href="<?php echo $settings->fblink ;?>" target="_blank"><img src="<?php echo $_SERVER['HOST']; ?>/images/fbicon2.png" /></a>
							<?php } ?>
							<?php if ($settings->twlink != '') { ?>
								<a href="<?php echo $settings->twlink ;?>" target="_blank"><img src="<?php echo $_SERVER['HOST']; ?>/images/twittericon.png" /></a>
							<?php } ?>
							<?php if ($settings->gplink != '') { ?>
								<a href="<?php echo $settings->gplink ;?>" target="_blank"><img src="<?php echo $_SERVER['HOST']; ?>/images/gplus.png" /></a>
							<?php } ?>
						<?php } ?>
						</p>
                    </div>
                </div>
                <div class="footer-border"></div>
                <div class="row">
                    <div class="copyright span4">
                        <p><?php echo stripslashes($settings->copyright); ?>
                    </div>
                    <div class="copyright" style="float: right;">
						<p><a href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/termsofuse.php">Terms of Use</a> | <a href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/privacy.php">Privacy Policy</a></p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Javascript -->
        
		<style>
			.btn_new { 
				background: <?php echo $settings->light_color; ?>;
				background-image: -webkit-linear-gradient(top, <?php echo $settings->light_color; ?>, <?php echo $settings->dark_color; ?>);
				background-image: -moz-linear-gradient(top, <?php echo $settings->light_color; ?>, <?php echo $settings->dark_color; ?>);
				background-image: -ms-linear-gradient(top, <?php echo $settings->light_color; ?>, <?php echo $settings->dark_color; ?>);
				background-image: -o-linear-gradient(top, <?php echo $settings->light_color; ?>, <?php echo $settings->dark_color; ?>);
				background-image: linear-gradient(to bottom, <?php echo $settings->light_color; ?>, <?php echo $settings->dark_color; ?>);
				
				color: #ffffff;
				font-size: 14px;
				font-weight: bold;
				padding: 10px 20px;
				
				-webkit-border-radius: 15px;
				-moz-border-radius: 15px;
				border-radius: 15px;
				border: none;
				text-decoration: none;
			}
			
			.btn_new:hover { 
				background: <?php echo $settings->dark_color; ?>;
				background-image: -webkit-linear-gradient(top, <?php echo $settings->dark_color; ?>, <?php echo $settings->light_color; ?>);
				background-image: -moz-linear-gradient(top, <?php echo $settings->dark_color; ?>, <?php echo $settings->light_color; ?>);
				background-image: -ms-linear-gradient(top, <?php echo $settings->dark_color; ?>, <?php echo $settings->light_color; ?>);
				background-image: -o-linear-gradient(top, <?php echo $settings->dark_color; ?>, <?php echo $settings->light_color; ?>);
				background-image: linear-gradient(to bottom, <?php echo $settings->dark_color; ?>, <?php echo $settings->light_color; ?>);
				
				color: #ffffff;
				font-size: 14px;
				padding: 10px 20px;
				font-weight: bold;
				-webkit-border-radius: 15px;
				-moz-border-radius: 15px;
				border-radius: 15px;
				border: none;
				text-decoration: none;
			}
		</style>



</body></html>