<?php include('paypalconfig.php'); ?>
<?php $settings = json_decode(file_get_contents('admin/data/settings.txt')); ?>

<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title><?php echo stripslashes($data->seo_title); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php echo $data->seo_des; ?>">
        <meta name="keywords" content="<?php echo $data->seo_key; ?>">

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Droid+Sans">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/prettyPhoto.css">
        <link rel="stylesheet" href="css/flexslider.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/style.css">

        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
         
        <![endif]-->

        <!-- Favicon and touch icons -->
      
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57-precomposed.png">
    
    <script src="js/jquery-1.8.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    </head>

    <body>
        <!-- Header -->
        <div class="container">
            <div class="header row">
                <div class="span12">
                    <div class="navbar">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <h1><a class="" style="max-height: 125px; href="index.php"><img src="<?php echo 'http://'.$_SERVER['HTTP_HOST'].'/admin/data/images/'.$settings->logo; ?>"/></a></h1>
                            <div class="nav-collapse collapse">
                                <ul class="nav pull-right">
									<?php
										$exploded = explode('/', $_SERVER['REQUEST_URI']);
                                        $pg = end($exploded);									
									?>
                                    <li class="<?php echo $pg == '' || $pg == 'index.php' ? "current-page": ""; ?>"><a href="index.php"><i class="icon-home"></i><br>Home</a></li>
        							<li class="<?php echo $pg == 'about.php' ? "current-page": ""; ?>"><a href="about.php"><i class="icon-user"></i><br>About</a></li>
                                    <li class="<?php echo $pg == 'products.php' ? "current-page": ""; ?>"><a href="products.php"><i class="icon-tasks"></i><br>Products</a></li>
                                    <li class="<?php echo $pg == 'seoservices.php' ? "current-page": ""; ?>"><a href="seoservices.php"><i class="icon-tasks"></i><br>SEO Services</a></li>
									<li class="<?php echo $pg == 'smservices.php' ? "current-page": ""; ?>"><a href="smservices.php"><i class="icon-tasks"></i><br>Social Media Services</a></li>
									
                                    <li class="<?php echo $pg == 'contact.php' ? "current-page": ""; ?>"><a href="contact.php"><i class="icon-envelope-alt"></i><br>Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<style>
			.header ul.nav li a:hover { background: <?php echo $settings->light_color ;?> }
			.header ul.nav li.current-page a { border-top: 5px solid <?php echo $settings->light_color ;?>; }
		</style>