<?php
	@session_start(session_id());
	//unset($_SESSION['admin']);
	
	/*ini_set('display_errors', 1);
	error_reporting(E_ALL);*/
	
	define('THUMB_SIZE',64);
	define('MEDIUM_SIZE',128);
	define('LARGE_SIZE',256);

	define('DOC_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/');
	define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/');
	define('ADMIN_URL', SITE_URL . 'admin/');
	
	if (!isset($_SESSION['admin']) && $_SESSION['admin'] != 'true') {
		header("Location: ".SITE_URL."admin/login.php" );
		die();
	}
	
	ob_start();
	if (!isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
		include 'header.php';
	}
?>