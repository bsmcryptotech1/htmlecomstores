<nav class="navbar-default navbar-static-side" role="navigation">
	<div class="sidebar-collapse">
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>home.php">Edit Home Page</a></li></ul>
        <ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>seohome.php">Edit SEO Page</a></li></ul>
        <ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>smhome.php">Edit SOCIAL MEDIA Page</a></li></ul>
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>about.php">Edit About Page</a></li></ul>
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>product.php">Edit Products Page</a></li></ul>
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>contact.php">Edit Contact Page</a></li></ul>
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>settings.php">Edit Settings</a></li></ul>
		<ul class="nav" id="side-menu"><li><a href="<?php echo ADMIN_URL; ?>logout.php">Logout</a></li></ul>
	</div>
</nav>
<?php $settings = json_decode(file_get_contents('data/settings.txt')); ?>