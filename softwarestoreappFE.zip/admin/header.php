<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<link href="<?php echo SITE_URL; ?>admin/css/bootstrap.min.css" media="screen" rel="stylesheet" type="text/css" />
		<link href="<?php echo SITE_URL; ?>admin/css/admin.css" media="screen" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo SITE_URL; ?>css/font-awesome.css">
		<script src="<?php echo SITE_URL; ?>admin/js/jquery-1.10.2.js"></script>
	</head>
	<body>
		<input type="hidden" name="sess_id" id="sess_id" value="<?php echo session_id(); ?>" />
		<div id="wrapper">
			<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo SITE_URL; ?>admin/">Admin Control Panel</a>
					<a href="http://<?php echo $_SERVER['HTTP_HOST'] ;?>" style="float: left; margin: 15px;" target="_blank">View Your Website <i class="icon-circle-arrow-right"></i> </a> 
				</div>
				
			</nav>
			<?php require_once 'left.php'; ?>