<?php require_once 'config.php'; ?>
<?php
	switch($settings->currency) {
		case 'USD': $sym = '$'; break;
		case 'GBP': $sym = '£'; break;
		case 'EUR': $sym = '€'; break;
	}
	$file = "data/service.txt";
	if (isset($_POST['Save'])) {
		if (count($_FILES) > 0) {
			if (isset($_FILES['service_img']) && count($_FILES['service_img']['name']) > 0) {
				$i = 1;
				foreach ($_FILES['service_img']['name'] as $k => $v) {
					if ($_FILES['service_img']['tmp_name'][$k] != '') {
						$valid_file = $_FILES['service_img']['tmp_name'][$k];
						$imagesizedata = getimagesize($valid_file);
						if ($imagesizedata !== false) {
							move_uploaded_file($_FILES['service_img']['tmp_name'][$k], 'data/images/'.$_FILES['service_img']['name'][$k]);
							$_REQUEST['service_img'][$i] = $_FILES['service_img']['name'][$k];
						}
						else {
							$_REQUEST['service_img'][$i] = isset($_REQUEST['service_img_old'][$i]) ? $_REQUEST['service_img_old'][$i] : '';
						}
					}
					$i++;
				}
			}
		}
		for($i = 1; $i <= $settings->total_services; $i++) {
			if ($_REQUEST['service_img'][$i] == '' && isset($_REQUEST['service_img_old'][$i])) {
				$_REQUEST['service_img'][$i] = $_REQUEST['service_img_old'][$i];
			}
		}
		$fh = fopen($file, 'w') or die("can't open file");
		fwrite($fh, json_encode($_REQUEST));
		fclose($fh);
	}
	if (file_exists($file))
		$data = json_decode(file_get_contents($file));
?>
			<div id="page-wrapper">
				<div class="row">
					<div class="col-lg-12">
						<h1 class="page-header">Services Page Content</h1>
					</div>
				</div>
				<div class="col-lg-12">
					<form class="form-horizontal" enctype="multipart/form-data" action="" method="post" role="form">
						<div class="form-group">
							<label class="col-sm-2 control-label">Page Intro</label>
							<div class="col-sm-6">
								<textarea class="form-control" rows="10" cols="30" name="intro"><?php echo stripslashes($data->intro); ?></textarea>
							</div>
						</div>
						<?php for ($i = 1; $i <= $settings->total_services; $i++) { ?>
							<div class="form-group">
								<label class="col-sm-2 control-label">Service <?php echo $i; ?></label>
								<div class="col-xs-4">
									<input type="text" class="form-control" name="service_name[<?php echo $i; ?>]" value="<?php echo stripslashes($data->service_name->$i); ?>" placeholder="Service Name" >
								</div>
								<div class="col-sm-1" style="text-align: left; padding-right: 0px; width: 2%;margin-top: 7px"><?php echo $sym; ?></div>
								<div class="col-xs-2" style="width: 14.5%; margin-left: -10px;">
									<input type="text" class="form-control" name="price[<?php echo $i; ?>]" value="<?php echo $data->price->$i; ?>" placeholder="Price" >
								</div>
								<div class="col-sm-8" style="width: 100%; margin-top: 2%;"></div>
								<div class="col-sm-2"></div>
								<div class="col-sm-6">
									<div class="col-sm-6"><input type="file" name="service_img[<?php echo $i; ?>]" ></div>
									<div class="col-sm-4">Size 150 x 150</div>
									<div class="col-sm-3"></div>
									<div class="col-sm-12"></div>
									<div class="col-sm-2"></div>
									<?php
										if ($data->service_img->$i != '' && file_exists('data/images/'.$data->service_img->$i)) {
											echo '<div class="col-sm-2"><img src="data/images/'.$data->service_img->$i.'" style="max-width: 150px;" /></div>';
											echo '<input type="hidden" name="service_img_old['.$i.']" value="'.$data->service_img->$i.'" />';
										}
									?>
								</div>
								<div class="col-sm-8" style="width: 100%; margin-top: 2%;"></div>
								<label class="col-sm-2 control-label">Description</label>
								<div class="col-sm-6">
									<textarea class="form-control" rows="8" cols="30" name="service_desc[<?php echo $i; ?>]"><?php echo stripslashes($data->service_desc->$i); ?></textarea>
								</div>
							</div>
						<?php } ?>
						
						<div class="form-group">
							<label class="col-sm-2 control-label">Thank You Page</label>
							<div class="col-sm-8"><?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/thankyou.php'; ?></div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Title</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_title" value="<?php echo $data->seo_title; ?>" placeholder="SEO Title" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Keywords</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_key" value="<?php echo $data->seo_key; ?>" placeholder="SEO Keywords" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Description</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_des" value="<?php echo $data->seo_des; ?>" placeholder="SEO Descryption" >
							</div>
						</div>
						<div class="col-xs-2"></div><input type="submit" class="btn btn-primary" value="Save" name="Save" />
						<div style="float: left; width: 100%; margin-top: 4%;"></div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>