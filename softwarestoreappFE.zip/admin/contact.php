<?php require_once 'config.php'; ?>
<?php
	$file = "data/contact.txt";
	if (isset($_POST['Save'])) {
		$fh = fopen($file, 'w') or die("can't open file");
		fwrite($fh, json_encode($_REQUEST));
		fclose($fh);
	}
	if (file_exists($file))
		$data = json_decode(file_get_contents($file));
?>
			<div id="page-wrapper">
				<div class="row">
					<div class="col-lg-12">
						<h1 class="page-header">Contact Page Content</h1>
					</div>
				</div>
				<div class="col-lg-12">
					<form class="form-horizontal" enctype="multipart/form-data" action="" method="post" role="form">
						<div class="form-group">
							<label class="col-sm-2 control-label">Address</label>
							<div class="col-sm-4">
								<textarea class="form-control" rows="8" name="address"><?php echo stripslashes($data->address); ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Address for Map</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="map_address" value="<?php echo $data->map_address; ?>" placeholder="Google Map Addresss" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Title</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_title" value="<?php echo $data->seo_title; ?>" placeholder="SEO Title" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Keywords</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_key" value="<?php echo $data->seo_key; ?>" placeholder="SEO Keywords" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO Description</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="seo_des" value="<?php echo $data->seo_des;  ?>" placeholder="SEO Descryption" >
							</div>
						</div>
						<div class="col-xs-2"></div><input type="submit" class="btn btn-primary" value="Save" name="Save" />
						<div style="float: left; width: 100%; margin-top: 4%;"></div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>

<?php 
	/*
	 *  Logo
		Main Headline
		Subheadline
		Paypal Email
		testimonial1 content, testimonial1 image (max 100x100), testimonial1 name
		testimonial2 content, testimonial2 image (max 100x100), testimonial2 name
		and so on upto testimonial5
	 */
?>