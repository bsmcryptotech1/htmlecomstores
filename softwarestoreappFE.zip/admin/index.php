<?php 
	include 'config.php';
	$file = "data/settings.txt";
	if (file_exists($file))
		$data = json_decode(file_get_contents($file));
?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12" style="margin-top: 10%">
		<center><h1>Welcome to Your</h1></center>
		<center>
			<?php 
				if ($data->logo != '' && file_exists('data/images/'.$data->logo)) {
					echo '<img src="data/images/'.$data->logo.'" />';
					echo '<input type="hidden" name="old_logo" value="'.$data->logo.'" />';
				}
			?>
		<br/><br/><br/><br/><br/></center>
	</div>
</div>