<?php 
$data = json_decode(file_get_contents('admin/data/product.txt'));
	include('includes/header.php');
	
	switch($settings->currency) {
		case 'USD': $sym = '$'; break;
		case 'GBP': $sym = '£'; break;
		case 'EUR': $sym = '€'; break;
	}
?>
<?php $btn = '<input type="submit" class="btn_new" value="Buy Now" />'; ?>
<!-- Page Title -->
<div class="page-title">
  <div class="container">
    <div class="row">
      <div class="span12"> <i class="icon-tasks page-title-icon"></i>
        <h2>Products /</h2>
        <p>Here are the products we offer</p>
      </div>
    </div>
  </div>
</div>

<!-- Services Full Width Text -->
<div class="services-full-width container">
  <div class="row">
    <div class="services-full-width-text span12">
      <h4>Our Products</h4>
      <p><?php echo stripslashes($data->intro); ?></p>
    </div>
  </div>
</div>

<!-- Services -->
<div class="what-we-do container">
	<?php for($i = 1; $i <= $settings->total_products; $i++) { ?>
			
			<div class="row">
				<div class="service span12">
					<p class="mg15"></p>
					<div class="left span2">
						<div class="icon-awesome "> <img src="http://<?php echo $_SERVER['HTTP_HOST']; ?>/admin/data/images/<?php echo $data->product_img->$i; ?>" style="max-width:150px;"> </div>
					</div>
					<div class="left span7 spleft"><h4><?php echo stripslashes($data->product_name->$i); ?></h4><p><?php echo stripslashes($data->product_desc->$i); ?></p></div>
					<div class="left span2 spleft" >
						<p></p>Price : <?php echo $sym; ?> <?php echo $data->price->$i; ?><br><p></p><p></p>
						<form id="signup" action="<?php echo paypal_path; ?>" method="post">
							<input type="hidden" name="cmd" value="_cart">
							<input type="hidden" name="business" value="<?php echo $settings->paypal; ?>">
							<input type="hidden" name="lc" value="US">
							<input type="hidden" name="add" value="1">
							<input type="hidden" name="item_name" value="<?php echo stripslashes($data->product_name->$i); ?>">
							<input type="hidden" name="amount" value="<?php echo $data->price->$i; ?>">
							<input type="hidden" name="return" value="<?php echo $data->link->$i; ?>">
							<input type="hidden" name="currency_code" value="<?php echo $settings->currency; ?>">
							<!-- <input type="image" src="images/bn.png" border="0" name="submit"> -->
							<?php echo $btn; ?>
						</form>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<br><br>
	<?php } ?>
</div>
</div>
<br/>
<br/>
<br/>
</div>
</div>
<style> .what-we-do .service { border-bottom: 2px solid <?php echo $settings->dark_color; ?>; }</style>
<?php include('includes/footer.php'); ?>