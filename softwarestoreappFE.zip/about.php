<?php 
	$data = json_decode(file_get_contents('admin/data/about.txt'));
	$settings = json_decode(file_get_contents('admin/data/settings.txt'));
	include('includes/header.php');
	$texts = stripslashes($data->texts);
	$texts = str_replace("\n", "<br>", $texts);
?>

        <!-- Page Title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="span12">
                        <i class="icon-user page-title-icon"></i>
                        <h2><?php echo stripslashes($data->main_headline); ?> /</h2>
                        <p><?php echo stripslashes($data->sub_headline); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- About Us Text -->
        <div class="about-us container">
            <div class="row">
                <div class="about-us-text" style="float: left; width: 75%; text-align: justify;">
                    <h4><?php echo stripslashes($data->content_title); ?></h4>
					<p><?php echo $texts ?></p>
                </div>
                <div style="float: left; width: 20%; margin-top: 30px;">
					<?php 
						if (count($settings->total_banners) > 0) {
							for($i = 1; $i <= $settings->total_banners; $i++) {
								if ($data->link->$i != '' && $data->banner_img->$i != '')
									echo '<div style="float: left; width: 100%; margin: 0 0 10px 0;"><a href="'.$data->link->$i.'"><img src="http://'.$_SERVER['HTTP_HOST'].'/admin/data/images/'.$data->banner_img->$i.'" style="max-width: 250px;" /></a></div>';
							}
						}
					?>
                </div>
            </div>
        </div>


        <?php include('includes/footer.php'); ?>