<?php
	$data = json_decode(file_get_contents('admin/data/contact.txt'));
	include('includes/header.php');
	if(isset($_REQUEST['name'])) {
		$to = $settings->email;
		$subject = 'Contact from Website';
		$headers = "From: " . strip_tags($_REQUEST['email']) . "\r\n";
		$headers .= "Reply-To: ". strip_tags($_REQUEST['email']) . "\r\n";
		//$headers .= "CC: susan@example.com\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		$message = "Hi, A message from contact form.";
		$message .= "<br /><br /><br />Name: ".$_REQUEST['name'];
		$message .= "<br />Email: ".$_REQUEST['email'];
		$message .= "<br />Subject: ".$_REQUEST['subject'];
		$message .= "<br />Message: ".$_REQUEST['message'];
		mail($to, $subject, $message, $headers);
		$msg = 'Your Message has been sent. Thank You.';
	}
	$btn = '<input type="submit" style="font-size: 14px; font-style: normal; height: auto; color: #fff; border-radius: 15px; border: none;" class="btn_new" value="SEND" />';
?>
<style type="text/css">
@media print {
.gm-style .gmnoprint, .gmnoprint {
	display:none
}
}
 @media screen {
.gm-style .gmnoscreen, .gmnoscreen {
	display:none
}
}
</style>
<script src="js/jquery-1.8.2.min.js"></script>
<!--<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>-->
<script src="js/gmap.min.js"></script>
<!-- Page Title -->
<div class="page-title">
        <div class="container">
    <div class="row">
		<div class="span12"> <i class="icon-envelope-alt page-title-icon"></i>
        <h2>Contact Us /</h2>
        <p>Here is how you can contact us</p>
      </div>
          </div>
  </div>
      </div>

<!-- Contact Us -->
<div class="contact-us container">
        <div class="row">
    <div class="contact-form span7">
        <?php
			if (isset($msg) && $msg != '')
				echo '<div class="alert alert-success" style="text-align: center;">'.$msg.'</div>';
		?>
        <p>If you have any questions regarding our services, kindly use the following form below to contact us.</p>
		<form method="post" action="">
	        <label for="name" class="nameLabel">Name</label>
	        <input id="name" type="text" name="name" placeholder="Enter your name...">
	        <label for="email" class="emailLabel">Email</label>
	        <input id="email" type="text" name="email" placeholder="Enter your email...">
	        <label for="subject">Subject</label>
	        <input id="subject" type="text" name="subject" placeholder="Your subject...">
	        <label for="message" class="messageLabel">Message</label>
	        <textarea id="message" name="message" placeholder="Your message..." name="message"></textarea>
	        <!-- <button type="submit">Send</button> -->
			<center><div style="margin: 0px auto; text-align: center; width: 100px;"><?php echo $btn; ?></div></center>
		</form>
          </div>
    <div class="contact-address span5">
         <!-- <h4>Contact Us</h4>
         <div id="map" style="float: left; width: 500px; height: 300px;">Map</div> -->
     <div class="clear"></div>
            <h4>Address</h4>
            <p><?php echo nl2br(stripslashes($data->address)) ?></p>
          </div>
          </div>
  </div>
<script>
jQuery(window).ready(function () {
	jQuery('#map').gMap({ address: "<?php echo stripslashes($data->map_address); ?>", zoom:5 });
});		
</script>
<?php include('includes/footer.php'); ?>